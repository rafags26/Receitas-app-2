import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import Navbar from "@/components/Navbar";
import RecipeForm from "@/components/RecipeForm";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function CreateRecipe() {
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [error, setError] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    const token = localStorage.getItem("authToken");
    const savedUsername = localStorage.getItem("username");
    
    if (!token) {
      setLocation("/");
      return;
    }

    setUsername(savedUsername || "");
  }, [setLocation]);

  const handleLogout = () => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("username");
    setLocation("/");
  };

  const createReceitaMutation = useMutation({
    mutationFn: async (recipe: { name: string; ingredients: string[]; preparation: string }) => {
      const response = await apiRequest("POST", "/api/receitas", recipe);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/receitas"] });
      
      toast({
        title: "Receita criada com sucesso!",
        description: `"${data.name}" foi adicionada às suas receitas.`,
      });
      
      setLocation("/dashboard");
    },
    onError: (err: any) => {
      setError(err.message || "Erro ao criar receita");
    },
  });

  const handleSubmit = async (recipe: { name: string; ingredients: string[]; preparation: string }) => {
    setError("");
    createReceitaMutation.mutate(recipe);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar 
        isAuthenticated={true} 
        username={username}
        onLogout={handleLogout}
      />
      
      <RecipeForm 
        onSubmit={handleSubmit}
        isLoading={createReceitaMutation.isPending}
        error={error}
      />
    </div>
  );
}
