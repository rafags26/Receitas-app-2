import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import RecipeCard from "@/components/RecipeCard";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2 } from "lucide-react";
import type { Receita } from "@shared/schema";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("authToken");
    const savedUsername = localStorage.getItem("username");
    
    if (!token) {
      setLocation("/");
      return;
    }

    setUsername(savedUsername || "");
  }, [setLocation]);

  const { data: recipes = [], isLoading, error } = useQuery<Receita[]>({
    queryKey: ["/api/receitas"],
    enabled: !!localStorage.getItem("authToken"),
  });

  const handleLogout = () => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("username");
    setLocation("/");
  };

  const handleCreateClick = () => {
    setLocation("/criar-receita");
  };

  const handleRecipeClick = (recipe: Receita) => {
    console.log('Recipe clicked:', recipe);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar 
        isAuthenticated={true} 
        username={username}
        onLogout={handleLogout}
      />
      
      <Hero onCreateClick={handleCreateClick} />

      <div className="container mx-auto px-6 py-12">
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{(error as any)?.message || "Erro ao carregar receitas"}</AlertDescription>
          </Alert>
        )}

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : recipes.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg mb-4">
              Nenhuma receita encontrada
            </p>
            <p className="text-sm text-muted-foreground">
              Comece criando sua primeira receita!
            </p>
          </div>
        ) : (
          <>
            <h2 className="text-2xl font-semibold mb-6">
              Minhas Receitas ({recipes.length})
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recipes.map((recipe) => (
                <RecipeCard
                  key={recipe.id}
                  {...recipe}
                  onClick={() => handleRecipeClick(recipe)}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
