import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ChefHat, LogOut, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface NavbarProps {
  isAuthenticated?: boolean;
  username?: string;
  onLogout?: () => void;
}

export default function Navbar({ isAuthenticated = false, username, onLogout }: NavbarProps) {
  const [location, setLocation] = useLocation();

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-6">
        <button 
          onClick={() => setLocation(isAuthenticated ? "/dashboard" : "/")}
          className="flex items-center gap-2 hover-elevate active-elevate-2 rounded-md px-3 py-2 -ml-3" 
          data-testid="link-home"
        >
          <ChefHat className="h-6 w-6 text-primary" />
          <span className="font-serif text-xl font-semibold">ReceitasApp</span>
        </button>

        <nav className="flex items-center gap-2">
          {isAuthenticated ? (
            <>
              <Badge variant="secondary" className="hidden sm:flex" data-testid="badge-username">
                {username || "Usuário"}
              </Badge>
              <Button 
                variant={location === "/criar-receita" ? "default" : "ghost"}
                size="sm"
                onClick={() => setLocation("/criar-receita")}
                data-testid="button-new-recipe"
              >
                <Plus className="h-4 w-4 sm:mr-2" />
                <span className="hidden sm:inline">Nova Receita</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={onLogout}
                data-testid="button-logout"
              >
                <LogOut className="h-4 w-4 sm:mr-2" />
                <span className="hidden sm:inline">Sair</span>
              </Button>
            </>
          ) : (
            <Button 
              variant="default" 
              size="sm"
              onClick={() => setLocation("/")}
              data-testid="button-login"
            >
              Entrar
            </Button>
          )}
        </nav>
      </div>
    </header>
  );
}
