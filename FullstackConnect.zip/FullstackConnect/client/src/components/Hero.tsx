import heroImage from '@assets/generated_images/Fresh_cooking_ingredients_hero_aca5d5b5.png';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';

interface HeroProps {
  onCreateClick?: () => void;
}

export default function Hero({ onCreateClick }: HeroProps) {
  return (
    <div className="relative h-64 w-full overflow-hidden">
      <img 
        src={heroImage} 
        alt="Fresh cooking ingredients"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/20 backdrop-blur-[2px]" />
      
      <div className="relative h-full container mx-auto px-6 flex flex-col items-center justify-center text-center">
        <h1 className="font-serif text-4xl md:text-5xl font-semibold text-white mb-4">
          Suas Receitas Favoritas
        </h1>
        <p className="text-white/90 text-lg mb-6 max-w-2xl">
          Organize, gerencie e compartilhe suas criações culinárias
        </p>
        <Button 
          size="lg"
          className="bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20"
          onClick={onCreateClick}
          data-testid="button-hero-create"
        >
          <Plus className="h-5 w-5 mr-2" />
          Criar Nova Receita
        </Button>
      </div>
    </div>
  );
}
