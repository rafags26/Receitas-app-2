import { useState } from 'react';
import RecipeForm from '../RecipeForm';

export default function RecipeFormExample() {
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (recipe: { name: string; ingredients: string[]; preparation: string }) => {
    console.log('Recipe submitted:', recipe);
    setIsLoading(true);
    
    setTimeout(() => {
      setIsLoading(false);
      console.log('Recipe saved successfully!');
    }, 1500);
  };

  return (
    <RecipeForm 
      onSubmit={handleSubmit}
      isLoading={isLoading}
    />
  );
}
