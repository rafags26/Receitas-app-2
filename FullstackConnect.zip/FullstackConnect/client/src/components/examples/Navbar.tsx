import Navbar from '../Navbar';

export default function NavbarExample() {
  return (
    <div className="space-y-8">
      <div>
        <p className="text-sm text-muted-foreground mb-4">Authenticated State</p>
        <Navbar 
          isAuthenticated={true} 
          username="João Silva"
          onLogout={() => console.log('Logout clicked')}
        />
      </div>
      <div>
        <p className="text-sm text-muted-foreground mb-4">Unauthenticated State</p>
        <Navbar isAuthenticated={false} />
      </div>
    </div>
  );
}
