import { useState } from 'react';
import LoginForm from '../LoginForm';

export default function LoginFormExample() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = (username: string, password: string) => {
    console.log('Login attempt:', { username, password });
    setIsLoading(true);
    setError("");
    
    setTimeout(() => {
      setIsLoading(false);
      if (username === "error") {
        setError("Usuário ou senha inválidos");
      } else {
        console.log('Login successful!');
      }
    }, 1500);
  };

  return (
    <LoginForm 
      onLogin={handleLogin}
      isLoading={isLoading}
      error={error}
    />
  );
}
