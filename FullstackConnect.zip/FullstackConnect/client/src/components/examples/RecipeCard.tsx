import RecipeCard from '../RecipeCard';
import chocolateCakeImg from '@assets/generated_images/Chocolate_cake_slice_0c72ec2b.png';

export default function RecipeCardExample() {
  const mockRecipeWithImage = {
    id: "1",
    name: "Bolo de Chocolate",
    ingredients: ["200g de chocolate meio amargo", "3 ovos", "1 xícara de açúcar", "1 xícara de farinha", "1/2 xícara de manteiga"],
    preparation: "Misture tudo e leve ao forno por 40 minutos",
    prepTime: "1h",
    servings: 8,
    imageUrl: chocolateCakeImg
  };

  const mockRecipeWithoutImage = {
    id: "2",
    name: "Receita sem Imagem",
    ingredients: ["Ingrediente 1", "Ingrediente 2", "Ingrediente 3"],
    preparation: "Modo de preparo",
    prepTime: "30min",
    servings: 4
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl">
      <div>
        <p className="text-sm text-muted-foreground mb-4">Com Imagem</p>
        <RecipeCard 
          {...mockRecipeWithImage}
          onClick={() => console.log('Recipe clicked:', mockRecipeWithImage.name)}
        />
      </div>
      <div>
        <p className="text-sm text-muted-foreground mb-4">Sem Imagem (Fallback)</p>
        <RecipeCard 
          {...mockRecipeWithoutImage}
          onClick={() => console.log('Recipe clicked:', mockRecipeWithoutImage.name)}
        />
      </div>
    </div>
  );
}
