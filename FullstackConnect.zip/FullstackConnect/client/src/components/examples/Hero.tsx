import Hero from '../Hero';

export default function HeroExample() {
  return (
    <Hero onCreateClick={() => console.log('Create recipe clicked')} />
  );
}
