import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface RecipeFormProps {
  onSubmit?: (recipe: { name: string; ingredients: string[]; preparation: string }) => void;
  isLoading?: boolean;
  error?: string;
}

export default function RecipeForm({ onSubmit, isLoading = false, error }: RecipeFormProps) {
  const [name, setName] = useState("");
  const [ingredientInput, setIngredientInput] = useState("");
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [preparation, setPreparation] = useState("");

  const handleAddIngredient = () => {
    if (ingredientInput.trim()) {
      setIngredients([...ingredients, ingredientInput.trim()]);
      setIngredientInput("");
    }
  };

  const handleRemoveIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (ingredients.length === 0) {
      return;
    }
    onSubmit?.({ name, ingredients, preparation });
  };

  return (
    <div className="container max-w-4xl mx-auto px-6 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <h1 className="font-serif text-4xl font-semibold mb-2">Nova Receita</h1>
          <p className="text-muted-foreground mb-8">
            Preencha os detalhes da sua receita
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <Alert variant="destructive">
                <AlertDescription data-testid="text-error">{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="name">Nome da Receita</Label>
              <Input
                id="name"
                type="text"
                placeholder="Ex: Bolo de Chocolate"
                value={name}
                onChange={(e) => setName(e.target.value)}
                disabled={isLoading}
                required
                data-testid="input-recipe-name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="ingredient">Ingredientes</Label>
              <div className="flex gap-2">
                <Input
                  id="ingredient"
                  type="text"
                  placeholder="Ex: 200g de chocolate"
                  value={ingredientInput}
                  onChange={(e) => setIngredientInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddIngredient())}
                  disabled={isLoading}
                  data-testid="input-ingredient"
                />
                <Button
                  type="button"
                  onClick={handleAddIngredient}
                  disabled={isLoading || !ingredientInput.trim()}
                  data-testid="button-add-ingredient"
                >
                  Adicionar
                </Button>
              </div>
              
              {ingredients.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {ingredients.map((ingredient, index) => (
                    <Badge 
                      key={index} 
                      variant="secondary"
                      className="pr-1"
                      data-testid={`badge-ingredient-${index}`}
                    >
                      {ingredient}
                      <button
                        type="button"
                        onClick={() => handleRemoveIngredient(index)}
                        className="ml-2 hover-elevate active-elevate-2 rounded-sm p-0.5"
                        data-testid={`button-remove-ingredient-${index}`}
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="preparation">Modo de Preparo</Label>
              <Textarea
                id="preparation"
                placeholder="Descreva o passo a passo..."
                value={preparation}
                onChange={(e) => setPreparation(e.target.value)}
                disabled={isLoading}
                required
                className="min-h-32"
                data-testid="input-preparation"
              />
            </div>

            <Button
              type="submit"
              className="w-full"
              disabled={isLoading || ingredients.length === 0}
              data-testid="button-submit"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Salvando...
                </>
              ) : (
                "Criar Receita"
              )}
            </Button>
          </form>
        </div>

        <div className="hidden lg:block">
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle>Preview</CardTitle>
              <CardDescription>Como sua receita ficará</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="h-48 bg-gradient-to-br from-orange-400 to-pink-500 rounded-lg flex items-center justify-center">
                <div className="text-6xl">🍳</div>
              </div>
              
              {name && (
                <h3 className="font-serif text-xl font-semibold">{name}</h3>
              )}
              
              {ingredients.length > 0 && (
                <div className="space-y-2">
                  <p className="text-sm font-medium">Ingredientes:</p>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    {ingredients.slice(0, 3).map((ingredient, idx) => (
                      <li key={idx}>• {ingredient}</li>
                    ))}
                    {ingredients.length > 3 && (
                      <li className="text-primary font-medium">+ {ingredients.length - 3} mais...</li>
                    )}
                  </ul>
                </div>
              )}
              
              {preparation && (
                <div className="space-y-2">
                  <p className="text-sm font-medium">Preparo:</p>
                  <p className="text-sm text-muted-foreground line-clamp-4">{preparation}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
