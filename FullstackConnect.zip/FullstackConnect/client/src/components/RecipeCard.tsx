import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Users } from "lucide-react";

interface RecipeCardProps {
  id: string;
  name: string;
  ingredients: string[];
  preparation: string;
  prepTime?: string;
  servings?: number;
  imageUrl?: string;
  onClick?: () => void;
}

export default function RecipeCard({
  name,
  ingredients,
  prepTime = "30 min",
  servings = 4,
  imageUrl,
  onClick
}: RecipeCardProps) {
  const displayIngredients = ingredients.slice(0, 3);
  const hasMore = ingredients.length > 3;

  return (
    <Card 
      className="overflow-hidden hover-elevate active-elevate-2 cursor-pointer transition-all"
      onClick={onClick}
      data-testid={`card-recipe-${name.toLowerCase().replace(/\s+/g, '-')}`}
    >
      {imageUrl ? (
        <div className="h-48 overflow-hidden">
          <img 
            src={imageUrl} 
            alt={name}
            className="h-full w-full object-cover"
          />
        </div>
      ) : (
        <div className="h-48 bg-gradient-to-br from-orange-400 to-pink-500 flex items-center justify-center">
          <div className="text-6xl">🍳</div>
        </div>
      )}
      
      <CardHeader className="pb-4">
        <h3 className="font-serif text-xl font-semibold line-clamp-2" data-testid="text-recipe-name">
          {name}
        </h3>
        <div className="flex items-center gap-4 text-sm text-muted-foreground mt-2">
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <span>{prepTime}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            <span>{servings} porções</span>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <div className="space-y-2">
          <p className="text-sm font-medium">Ingredientes:</p>
          <ul className="text-sm text-muted-foreground space-y-1">
            {displayIngredients.map((ingredient, idx) => (
              <li key={idx} className="line-clamp-1">• {ingredient}</li>
            ))}
            {hasMore && (
              <li className="text-primary font-medium">+ {ingredients.length - 3} mais...</li>
            )}
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
