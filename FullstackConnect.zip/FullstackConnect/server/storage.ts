import { type User, type InsertUser, type Receita, type InsertReceita } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getReceitas(userId: string): Promise<Receita[]>;
  createReceita(receita: InsertReceita): Promise<Receita>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private receitas: Map<string, Receita>;

  constructor() {
    this.users = new Map();
    this.receitas = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getReceitas(userId: string): Promise<Receita[]> {
    return Array.from(this.receitas.values()).filter(
      (receita) => receita.userId === userId,
    );
  }

  async createReceita(insertReceita: InsertReceita): Promise<Receita> {
    const id = randomUUID();
    const receita: Receita = { ...insertReceita, id };
    this.receitas.set(id, receita);
    return receita;
  }
}

export const storage = new MemStorage();
