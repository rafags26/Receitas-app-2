import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertReceitaSchema } from "@shared/schema";
import { randomUUID, createHash } from "crypto";

function hashPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

interface AuthRequest extends Request {
  userId?: string;
}

const authMiddleware = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: "Token não fornecido" });
  }

  const token = authHeader.substring(7);
  
  if (!token || !token.startsWith('user-')) {
    return res.status(401).json({ message: "Token inválido" });
  }

  const userId = token.replace('user-', '');
  const user = await storage.getUser(userId);
  
  if (!user) {
    return res.status(401).json({ message: "Usuário não encontrado" });
  }

  req.userId = userId;
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = insertUserSchema.parse(req.body);
      const hashedPassword = hashPassword(password);

      let user = await storage.getUserByUsername(username);
      
      if (!user) {
        user = await storage.createUser({ username, password: hashedPassword });
      } else {
        if (user.password !== hashedPassword) {
          return res.status(401).json({ message: "Credenciais inválidas" });
        }
      }

      const token = `user-${user.id}`;
      
      res.json({ 
        token, 
        username: user.username,
        message: "Login realizado com sucesso" 
      });
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Erro ao fazer login" });
    }
  });

  app.get("/api/receitas", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const receitas = await storage.getReceitas(req.userId!);
      res.json(receitas);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Erro ao buscar receitas" });
    }
  });

  app.post("/api/receitas", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const receitaData = insertReceitaSchema.parse({
        ...req.body,
        userId: req.userId
      });

      const receita = await storage.createReceita(receitaData);
      
      res.status(201).json(receita);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Erro ao criar receita" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
