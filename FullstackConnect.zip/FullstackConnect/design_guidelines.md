# Design Guidelines: Recipe Management Full-Stack Application

## Design Approach
**System-Based with Productivity Focus**: Inspired by Linear and Notion's clean data management interfaces, adapted for recipe content. Emphasis on clarity, efficient workflows, and visual hierarchy that supports the learning objective of demonstrating full-stack integration.

## Typography System
- **Primary Font**: Inter (Google Fonts) - for all UI elements, forms, and data display
- **Display Font**: Playfair Display (Google Fonts) - for recipe titles and hero headline only
- **Scale**: 
  - Hero/Page Titles: text-4xl (Playfair Display, font-semibold)
  - Section Headers: text-2xl (Inter, font-semibold)
  - Form Labels: text-sm (Inter, font-medium, uppercase, tracking-wide)
  - Body/Input Text: text-base (Inter, font-normal)
  - Helper Text: text-sm (Inter, font-normal)

## Layout System
**Spacing Primitives**: Use Tailwind units of 2, 4, 6, and 8 consistently
- Component padding: p-6
- Section spacing: py-12 or py-16
- Form field gaps: gap-6
- Card padding: p-6
- Container max-width: max-w-6xl

## Page Structures

### Login Page
- Centered single-column layout (max-w-md mx-auto)
- Full viewport height with vertical centering
- Logo/brand name at top
- Form card with elevated shadow
- No hero image - clean, focused authentication experience

### Dashboard/Recipe List Page
- **Hero Section** (h-64): Full-width banner with food photography showing fresh ingredients or cooking scene
  - Headline overlay with semi-transparent dark background (backdrop-blur-md bg-black/40)
  - "Add New Recipe" CTA button with blurred background
- **Recipe Grid**: 3-column layout (grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6)
- Sticky header with navigation and user menu

### Recipe Creation Page
- Two-column desktop layout (grid-cols-1 lg:grid-cols-2)
- Left: Form inputs
- Right: Live preview card showing how recipe will appear
- Mobile: Stacked single column

## Component Library

### Forms
- **Input Fields**: 
  - Full-width with rounded-lg borders
  - Height: h-12 for text inputs
  - Padding: px-4
  - Clear focus states with ring treatment
- **Text Areas**: min-h-32 for ingredients/preparation
- **Submit Buttons**: Full-width on mobile, w-auto px-8 on desktop
- **Validation**: Inline error messages below fields (text-sm)

### Recipe Cards
- Rounded-xl with subtle shadow (shadow-md hover:shadow-lg transition)
- Card structure:
  - Image placeholder area (aspect-video, bg-gradient treatment if no image)
  - Content padding: p-6
  - Recipe name: text-xl font-semibold
  - Metadata row: prep time, servings (text-sm with icons)
  - Ingredients preview: First 3 ingredients with "..." indicator

### Navigation
- Horizontal navbar (sticky top-0)
- Height: h-16
- Logo left, nav items center, user menu right
- Hamburger menu for mobile (< md breakpoint)

### Loading States
- Skeleton screens for recipe cards (animate-pulse)
- Spinner for form submissions (inline with button)
- Shimmer effect for list loading

### Authentication UI
- Login card: centered, max-w-md, shadow-xl
- Token indicator: Small badge showing logged-in state
- Logout button: Ghost style in navigation

## Data Display Patterns

### Recipe List
- Empty state: Centered illustration placeholder with "Add your first recipe" CTA
- Each recipe card displays: image area, title, metadata, short ingredient list
- Hover state: Subtle scale transform (hover:scale-105)

### Recipe Detail View
- Two-column layout: 
  - Left: Large image (if available), otherwise gradient
  - Right: Full recipe details (ingredients list, preparation steps)
- Steps numbered with large display numbers (text-4xl opacity-20)

## Interaction Patterns
- Form submission shows loading state immediately
- Success: Brief toast notification + redirect to recipe list
- Error: Inline validation messages, form stays populated
- Private route redirect: Smooth transition to login with return URL preserved

## Images

### Hero Image (Dashboard)
**Placement**: Top of recipe listing page, full-width
**Description**: Vibrant overhead shot of fresh cooking ingredients - colorful vegetables, herbs, wooden cutting board. Bright, appetizing, professional food photography style.
**Treatment**: Overlay with dark gradient from top, text remains readable

### Recipe Card Placeholders
**Description**: When no user image provided, use gradient backgrounds (e.g., from-orange-400 to-pink-500) with subtle food-related icon
**No actual images needed**: Use CSS gradients for MVP demonstration

## Responsive Behavior
- **Mobile** (< 768px): Single column everything, full-width cards, stacked forms
- **Tablet** (768px - 1024px): 2-column recipe grid, side-by-side form preview
- **Desktop** (> 1024px): 3-column recipe grid, full two-column layouts

## State Management Visual Cues
- **Loading**: Pulsing skeleton + disabled form controls
- **Error**: Red border + error icon + message below field
- **Success**: Green checkmark icon + success message
- **Authenticated**: User avatar/initials in navigation
- **Unauthenticated**: "Login" button in navigation

This design creates a clean, professional recipe management interface that clearly demonstrates full-stack integration while remaining visually appealing and functionally efficient.