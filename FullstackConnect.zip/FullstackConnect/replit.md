# ReceitasApp - Sistema de Gerenciamento de Receitas

## Visão Geral
Aplicação full-stack para gerenciamento de receitas desenvolvida como projeto educacional "Missão 10 – A Grande Conexão". O objetivo é demonstrar a integração completa entre frontend e backend, desde autenticação até CRUD de receitas.

## Estado Atual
**✨ Integração Full-Stack Completa**
- ✅ Interface de login funcional com validação de formulário
- ✅ Dashboard com listagem de receitas em grid responsivo
- ✅ Formulário de criação de receitas com preview em tempo real
- ✅ Hero section com imagem gerada
- ✅ Navegação entre páginas (Login, Dashboard, Criar Receita)
- ✅ Sistema de autenticação com backend (SHA-256 password hashing)
- ✅ Design responsivo para mobile, tablet e desktop
- ✅ **Backend API integrado com frontend**
- ✅ **TanStack Query para gerenciamento de estado**
- ✅ **In-memory storage funcionando**
- ✅ **Teste end-to-end aprovado**

## Estrutura do Projeto

### Frontend (React + TypeScript)
```
client/src/
├── pages/
│   ├── Login.tsx           # Página de autenticação
│   ├── Dashboard.tsx       # Lista de receitas com hero
│   └── CreateRecipe.tsx    # Formulário de criação
├── components/
│   ├── Navbar.tsx          # Barra de navegação
│   ├── Hero.tsx            # Hero section com imagem
│   ├── LoginForm.tsx       # Formulário de login
│   ├── RecipeCard.tsx      # Card individual de receita
│   └── RecipeForm.tsx      # Formulário de criação
```

### Backend (Express + TypeScript)
```
server/
├── routes.ts              # Endpoints da API (login, receitas)
├── storage.ts             # Interface de armazenamento (MemStorage)
├── index.ts               # Servidor Express
└── shared/schema.ts       # Tipos compartilhados (Drizzle + Zod)
```

## Funcionalidades Implementadas

### Autenticação (Backend + Frontend)
- ✅ Login com username e senha
- ✅ Criação automática de usuário no primeiro login
- ✅ Hashing de senha com SHA-256
- ✅ Token bearer para autenticação (formato: user-{id})
- ✅ Armazenamento de token em localStorage
- ✅ Proteção de rotas (redirecionamento se não autenticado)
- ✅ Logout com limpeza de sessão
- ✅ Middleware de autenticação no backend

### Gerenciamento de Receitas (Backend + Frontend)
- ✅ Listagem de receitas em grid 3 colunas
- ✅ Cards com preview de ingredientes
- ✅ Formulário com validação em tempo real
- ✅ Preview ao vivo da receita sendo criada
- ✅ Sistema de tags para ingredientes
- ✅ **Criação de receitas via API (POST /api/receitas)**
- ✅ **Listagem de receitas via API (GET /api/receitas)**
- ✅ **Integração com TanStack Query**
- ✅ **Cache invalidation após mutations**
- ✅ **Loading states durante requisições**
- ✅ **Tratamento de erros de API**

### API Endpoints Implementados
1. ✅ **POST /api/login** - Autenticação/criação de usuários
2. ✅ **GET /api/receitas** - Listar receitas do usuário autenticado
3. ✅ **POST /api/receitas** - Criar nova receita
4. ✅ **Middleware authMiddleware** - Validação de tokens bearer

## Possíveis Melhorias Futuras

### Segurança Avançada
1. Substituir SHA-256 por bcrypt (mais seguro para produção)
2. Implementar JWT assinado em vez de token simples
3. Adicionar rate limiting
4. Implementar refresh tokens

### Funcionalidades Extras
1. Edição de receitas existentes
2. Exclusão de receitas com confirmação
3. Upload de imagens para receitas
4. Busca e filtros de receitas
5. Categorização de receitas
6. Avaliação e comentários

## Design System
- **Cores Primárias**: Laranja (#D97706) para ações principais
- **Tipografia**: Inter (UI) + Playfair Display (títulos)
- **Espaçamento**: Sistema consistente (p-6 para containers)
- **Componentes**: Shadcn/UI com customização
- **Dark Mode**: Suporte completo via CSS variables

## Sistema de Armazenamento
- **In-memory storage (MemStorage)**: Dados persistem durante execução do servidor
- **Autenticação real**: Senhas são hasheadas com SHA-256
- **Separação por usuário**: Cada usuário vê apenas suas próprias receitas
- **Auto-criação de usuários**: Primeiro login cria novo usuário automaticamente

## Tecnologias
- **Frontend**: React, TypeScript, Wouter (routing), TailwindCSS, Shadcn/UI
- **Backend**: Express.js, TypeScript
- **Storage**: In-memory (MemStorage)
- **Validação**: Zod + Drizzle-Zod
- **State Management**: TanStack Query v5
- **Autenticação**: Bearer tokens com SHA-256 password hashing
- **Imagens**: Geradas com AI (hero + 6 receitas exemplo)

## Observações de Desenvolvimento
- Sistema de rotas implementado com Wouter
- Formulários usam state management local + React Hook Form
- Preview da receita atualiza em tempo real
- Navegação protegida verifica token no useEffect
- TanStack Query gerencia cache e invalidação
- Middleware de autenticação valida Bearer tokens
- Tipos compartilhados entre frontend e backend (shared/schema.ts)
- Test IDs em todos elementos interativos (data-testid)

## Testes
- ✅ **E2E Test Aprovado**: Fluxo completo login → listar → criar receita
- ✅ Navegação entre páginas
- ✅ Autenticação e autorização
- ✅ CRUD de receitas
- ✅ Logout e redirecionamento
